package org.example.payingguestapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayingGuestApplicationTests {

    @Test
    void contextLoads() {
    }

}
