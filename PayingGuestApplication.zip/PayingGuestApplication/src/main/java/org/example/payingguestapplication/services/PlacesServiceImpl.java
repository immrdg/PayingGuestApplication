package org.example.payingguestapplication.services;

import org.example.payingguestapplication.exceptions.UnauthorizedAccessException;
import org.example.payingguestapplication.models.Owner;
import org.example.payingguestapplication.models.Places;
import org.example.payingguestapplication.repositories.OwnerRepository;
import org.example.payingguestapplication.repositories.PlacesRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlacesServiceImpl implements PlacesService {

    private final PlacesRepository placesRepository;
    private final OwnerRepository ownerRepository;

    PlacesServiceImpl(PlacesRepository placesRepository, OwnerRepository ownerRepository
    ){

        this.placesRepository = placesRepository;
        this.ownerRepository = ownerRepository;
    }
    @Override
    public void savePlaceForOwner(Places place, String ownerEmail) {
        Owner owner = ownerRepository.findByEmail(ownerEmail);
        if(owner == null){
            throw new UnauthorizedAccessException("Invalid owner email: " + ownerEmail);
        }

        place.setOwner(owner);
        placesRepository.save(place);
    }

    @Override
    public Places getPlaceById(Integer placeId) {
        return placesRepository.findById(placeId).orElse(null);
    }

    @Override
    public List<Places> getAllPlaces() {
        return placesRepository.findAll();
    }

    @Override
    public List<Places> getAllPlacesByCity(String city) {
        return placesRepository.getAllPlacesByCityContainingIgnoreCase(city);
    }
}
