package org.example.payingguestapplication.models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Places {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "places_id_generator")
    @SequenceGenerator(name = "places_id_generator", sequenceName = "places_sequence")
    private Integer id;

    private String name;

    private String address;

    private String city;

    private String country;

    private double rent;

    @Enumerated(value = EnumType.STRING)
    private Status status;

    @ManyToOne
    private Owner owner;
}
