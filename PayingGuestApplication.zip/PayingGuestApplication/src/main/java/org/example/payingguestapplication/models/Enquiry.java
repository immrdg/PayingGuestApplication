package org.example.payingguestapplication.models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Enquiry {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "enq_id_generator")
    @SequenceGenerator(name = "enq_id_generator", sequenceName = "enq_sequence")
    private Long id;


    @ManyToOne
    private Tenant tenant;

    @ManyToOne
    private Places place;

}
