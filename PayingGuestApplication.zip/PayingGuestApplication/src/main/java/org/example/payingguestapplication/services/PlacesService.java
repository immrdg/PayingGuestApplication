package org.example.payingguestapplication.services;

import org.example.payingguestapplication.models.Places;

import java.util.List;

public interface PlacesService {
    void savePlaceForOwner(Places place, String ownerEmail);

    Places getPlaceById(Integer placeId);

    List<Places> getAllPlaces();

    List<Places> getAllPlacesByCity(String city);
}
