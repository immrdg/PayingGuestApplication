package org.example.payingguestapplication.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.example.payingguestapplication.exceptions.UnauthorizedAccessException;
import org.example.payingguestapplication.models.Places;
import org.example.payingguestapplication.services.AuthenticationService;
import org.example.payingguestapplication.services.PlacesService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping({"/owner/places/","/pg/places/"})
public class PlacesController {

    private final AuthenticationService authenticationService;
    private final PlacesService placesService;

    PlacesController(AuthenticationService authenticationService, PlacesService placesService){

        this.authenticationService = authenticationService;
        this.placesService = placesService;
    }

    @GetMapping("add-new")
    public String addPlaceForm(HttpServletRequest request, Model model)  {

        if(!authenticationService.isAuthenticated(request,"owner"))
            throw new UnauthorizedAccessException("You must be logged in");

        return "addPlace";
    }

    @PostMapping("add-new")
    public String addPlace(HttpServletRequest request, @ModelAttribute Places place)   {
        if(!authenticationService.isAuthenticated(request,"owner"))
            throw new UnauthorizedAccessException("You must be logged in");
        HttpSession session=request.getSession(false);
        String email = (String) session.getAttribute("email");
        placesService.savePlaceForOwner(place,email);
        return "redirect:/owner/places";
    }

    //

    @GetMapping("edit/{place_id}")
    public String editPlaceForm(HttpServletRequest request, Model model, @PathVariable Integer place_id)  {
        if(!authenticationService.isAuthenticated(request,"owner"))
            throw new UnauthorizedAccessException("You must be logged in");

        model.addAttribute("place",placesService.getPlaceById(place_id));
        return "editPlace";
    }

    @PostMapping("edit/{place_id}")
    public String editPlaceForm(HttpServletRequest request, @ModelAttribute Places place, @PathVariable String place_id)   {
        if(!authenticationService.isAuthenticated(request,"owner"))
            throw new UnauthorizedAccessException("You must be logged in");
        HttpSession session=request.getSession(false);
        String email = (String) session.getAttribute("email");
        placesService.savePlaceForOwner(place,email);
        return "redirect:/owner/places";
    }
    @GetMapping("details/{place_id}")
    public String viewPlace(HttpServletRequest request, Model model, @PathVariable Integer place_id)  {
        if(!authenticationService.isAuthenticated(request))
            throw new UnauthorizedAccessException("You must be logged in");

        model.addAttribute("place",placesService.getPlaceById(place_id));
        return "display";
    }


}
