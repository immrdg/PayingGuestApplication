package org.example.payingguestapplication.services;

import org.example.payingguestapplication.models.Owner;
import org.example.payingguestapplication.models.Places;
import org.example.payingguestapplication.models.Tenant;
import org.example.payingguestapplication.repositories.OwnerRepository;
import org.example.payingguestapplication.repositories.PlacesRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OwnerServiceImpl implements OwnerService {

    private final OwnerRepository ownerRepository;
    private final PlacesRepository placesRepository;

    public OwnerServiceImpl(OwnerRepository ownerRepository, PlacesRepository placesRepository){
        this.ownerRepository = ownerRepository;
        this.placesRepository = placesRepository;
    }

    @Override
    public Owner getOwner(String email, String password) {
        return ownerRepository.findByEmailAndPassword(email, password);
    }

    @Override
    public Owner saveOwner(Owner owner) {
        return ownerRepository.save(owner);
    }

    @Override
    public List<Places> getPlacesByOwnerEmail(String email) {
        return placesRepository.getPlacesByOwnerEmail(email);
    }
}
