package org.example.payingguestapplication.services;

import org.example.payingguestapplication.models.Owner;
import org.example.payingguestapplication.models.Places;
import org.example.payingguestapplication.models.Tenant;

import java.util.List;

public interface OwnerService {
    Owner getOwner(String email, String password);

    Owner saveOwner(Owner owner);

    List<Places> getPlacesByOwnerEmail(String email);
}
